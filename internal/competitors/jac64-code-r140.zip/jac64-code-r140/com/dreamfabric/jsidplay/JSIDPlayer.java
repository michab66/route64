/**
 * This file is a part of JSIDPlay - a Java SID Player
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;
import com.dreamfabric.jac64.*;
import com.dreamfabric.c64utils.*;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 *
 *
 * @author  Joakim Eriksson (joakime@sics.se)
 * @version $Revision: 1.3 $, $Date: 2006/04/08 10:06:02 $
 */
public abstract class JSIDPlayer implements Runnable, M6510Ops {

  public static final boolean DEBUG = true;//false;
  public static boolean AUTODEBUG = false;//true;//false;
  public static final int PSID = 1;
  public static final int RSID = 2;

  public static final int V_PAL = 1;
  public static final int V_NTSC = 2;
  public static final int V_BOTH = 3;

  public static final String[] TYPE_NAMES = {"", "PSID", "RSID"};

  public static final String[] VIDEO_NAMES = {"", "PAL", "NTSC", "PAL & NTSC"};

  private JSCPU cpu;
  public JSIDChipemu sids;
  public IMonitor imon;
  public Loader loader;

  private int repaint;

  long startTime;

  int[] memory;
  int version;
  int offset;
  int addr;
  int iaddr;
  int paddr;
  int startAddress;
  int startPageAddress;
  int loadEndAddress;
  int songCount;
  int startsong;
  int songadr;
  int type;
  int videoMode = 0;
  long speed;
  boolean autoInstalls = false;

  String sidName = "sids/City.sid";
  String hvscBase = "";

  int currentSong = 0;
  int nxtSong;

  int effect = 0;

  String songName;
  String songAuthor;
  String songCopyright;

  Assembler asm;

  private boolean enableTimers;

  // Should return a SID object ??
  public boolean readSID(InputStream stream) {
    byte[] start = new byte[0x16];
    // dirNames.removeAllElements();
    // type = SID;
    startPageAddress = 0;
    try {
      DataInputStream reader = new DataInputStream(stream);
      reader.readFully(start);

      String st = new String(start);

      if (st.startsWith("PSID") || st.startsWith("RSID")) {
	type = st.startsWith("RSID") ? RSID : PSID;
	version = (start[4] & 0xff) * 256 + (start[5] & 0xff);
	offset = (start[6] & 0xff) * 256 + (start[7] & 0xff);
	addr = (start[8] & 0xff) * 256 + (start[9] & 0xff);
	iaddr = (start[10] & 0xff) * 256 + (start[11] & 0xff);
	paddr = (start[12] & 0xff) * 256 + (start[13] & 0xff);
	songCount = (start[14] & 0xff) * 256 + (start[15] & 0xff);
	startsong = (start[16] & 0xff) * 256 + (start[17] & 0xff) - 1;
	speed = (((start[18]&0xff) << 24) + ((start[19]&0xff)<<16) +
		 ((start[20]&0xff) << 8) + (start[21]&0xff));

	if (startsong < 0) startsong = 0;

	if (DEBUG) {
	  System.out.println("FOUND SID TUNE!");
	  System.out.println("Type: " + TYPE_NAMES[type]);
	  System.out.println("Version: " + version);
	  System.out.println("LoadAddr: " + addr +
			     " (" + Integer.toString(addr, 16) + ")");
	  System.out.println("InitAddr: " + iaddr +
			     " (" + Integer.toString(iaddr, 16) + ")");
	  System.out.println("PlayAddr: " + paddr +
			     " (" + Integer.toString(paddr, 16) + ")");
	  System.out.println("SongCount: " + songCount);
	  System.out.println("StartSong: " + startsong);
	  System.out.println("Speed: " + Long.toString(speed, 2));
	}

	songName = getString(reader);
	songAuthor = getString(reader);
	songCopyright = getString(reader);
	System.out.println("--------------------------");
	System.out.println("Name      :" + songName);
	System.out.println("Author    :" + songAuthor);
	System.out.println("Copyright :" + songCopyright);

	if (version == 2) {
	  byte[] v2data = new byte[6];
	  reader.readFully(v2data);
	  int flags = (v2data[0] << 8) + v2data[1];
	  System.out.println("Version 2 flags: " + flags);

	  videoMode = (flags >> 2) & 3;

	  System.out.println("VideoMode: " + VIDEO_NAMES[videoMode]);


	  System.out.println("Start Page     : " + (v2data[2] & 0xff));
	  System.out.println("Page length    : " + (v2data[3] & 0xff));
	  startPageAddress = (v2data[2] & 0xff) * 0x100;
	  System.out.println("StartPageAddress: " + startPageAddress);
	}

	byte[] adr = new byte[2];
	reader.readFully(adr);
	startAddress = ((adr[1]&0xff)*256 + (adr[0]&0xff));

	System.out.println("Loading SID into: " + startAddress +
			   " (" + Integer.toString(startAddress, 16)
			   + ")");
	// READ ALL THE BYTES OF THE SID!!!!
	int byt;
	int sadr = startAddress;
	try {
	  while((byt = reader.read()) != -1) {
	    setMemory(sadr++, byt & 0xff);
	  }
	} catch (Exception eof) {
	  System.out.println("Exception " + eof);
	  System.out.println("End of file: " + sadr + " (" +
			     Integer.toString(sadr, 16) + ")");
	} finally {
	  loadEndAddress = sadr - 1;
	  reader.close();
	}
      }
      System.out.println("End of SID file: " + loadEndAddress + " (" +
			 Integer.toString(loadEndAddress, 16) + ")");
      enableTimers = type == RSID || speed != 0;
      sids.enableTimers(enableTimers);

      setSongInfo(getSongInfo());

      return true;
    } catch(Exception e) {
      System.out.println("Error while reading SID");
    }
    return false;
  }

  private String getString(DataInputStream reader) throws IOException {
    byte[] str = new byte[0x20];
    reader.readFully(str);

    for (int i = 0, n = 0x20; i < n; i++) {
      if (str[i] == 0) {
	return new String(str, 0, i);
      }
    }
    return new String(str);
  }

  public void setAutoDebug() {
    AUTODEBUG = true;
  }

  public void playSID() {
    int i = 0;
    setStatus("Starting play");
    while (!sids.isReady() && i < 50) {
      System.out.println("Waiting for CPU..." + i);
      try {
	i++;
	Thread.sleep(500);
      } catch (Exception e) {
	e.printStackTrace();
      }
    }

    if (sids.isReady()) {
      initSID();
      if (AUTODEBUG) {
	System.out.println("AUTODEBUG ON!");
	imon.setEnabled(true);
	imon.setLevel(10);
      }
      setStatus("song " + (currentSong + 1) + "/" + songCount);
    } else {
      setStatus("CPU not ready");
    }
  }

  public int getPlaySec() {
    if (startTime == 0) return 0;
    return (int) ((System.currentTimeMillis() - startTime) / 1000);
  }


  public String getPlayTime() {
    int sec = getPlaySec();
    if (sec < 10) return "00:0" + sec;
    if (sec < 60) return "00:" + sec;
    if (sec < 600) return "0" + (sec / 60) + ":" + (sec % 60);
    return "" + (sec / 60) + ":" + (sec % 60);
  }

  public void playSong(int index) {
    startTime = System.currentTimeMillis();
    // change song no and notify player!
    asm.setByteValue("playnum", index);
    asm.setByteValue("changeplay", 1);
    currentSong = index;

    setStatus("song " + (index + 1) + "/" + songCount);
  }

  public int songCount() {
    return songCount;
  }

  public void nextSong() {
    currentSong = (currentSong + 1) % songCount;
    playSong(currentSong);
  }

  public void previousSong() {
    currentSong = (currentSong + songCount - 1) % songCount;
    playSong(currentSong);
  }


  public void setEffect(int effect) {
//    effect = effect % sids.mixer.getEFXCount();
//    sids.mixer.setEFX(effect);
  }

  public void initSID() {
    startTime = System.currentTimeMillis();
    if (songCount == 0) {
      System.out.println("Error - song count = 0!");
      return;
    }
    nxtSong = (startsong + 1) % songCount;
    currentSong = startsong;

    // should halt the CPU???

    // Should add
    //	$0000 to $9FFF -> $01 = #$07
    //  $A000 to $CFFF -> $01 = #$06
    //	$D000 to $DFFF -> $01 = #$00
    //  $E000 to $FFFF -> $01 = #$05

    int bank = 7;
    int playBank = 7;
    if (startAddress < 0xc000 &&
	(loadEndAddress > 0xa000 && loadEndAddress < 0xd000)) {
      System.out.println("BANK: BASIC OFF!!!");
      bank = 6;
      playBank = 6;
    } else if ((startAddress >= 0xd000 && startAddress < 0xdfff) ||
	       (loadEndAddress >= 0xd000 && loadEndAddress < 0xdfff)) {
      bank = 0;
      playBank = 0;
    } else if (startAddress >= 0xe000 || loadEndAddress >= 0xe000) {
      System.out.println("BANK: KERNAL OFF!!!");
      bank = 5;
      playBank = 5;
    }

    // What if paddr = 0 here???

    if (paddr < 0xa000)
      playBank = 7;  // Basic-ROM, Kernal-ROM, I/O
    else if (paddr  < 0xd000)
      playBank = 6;  // Kernal-ROM, I/O
    else if (paddr >= 0xe000)
      playBank = 5;  // I/O only


    System.out.println("InitBank: " + bank);
    System.out.println("PlayBank: " + playBank);

    cpu.freeze();

    if (asm == null) {
      asm = new Assembler();
      asm.setMemory(memory);
    }
    int address = 0x800;
    if (startAddress < 0x900 &&
	loadEndAddress < 0xc000) {
      address = 0xc000;
    }
    if (startAddress < 0x900 &&
	loadEndAddress > 0xc000 &&
	startAddress > 0x500) {
      address = 0x400;
    }

    if (startPageAddress != 0) {
      address = startPageAddress;
    }

    asm.assemble(loader.getResourceString("/sidplay.a65"), address);
    int startAt = asm.getLabelAddress("cold");

    // Setup the values in the player
    asm.setByteValue("playnum", startsong);
    System.out.println("PlayVec:  " + paddr);
    asm.setWordValue("playvec", paddr);

    asm.setWordValue("initvec", iaddr);
    asm.setByteValue("initiomap", 0x30 | bank);
    if (type != RSID && paddr != 0)
      asm.setByteValue("playiomap", 0x30 | playBank);
    else
      asm.setByteValue("playiomap", 0);
    asm.setByteValue("speed", (int) (speed & 0xff));

    if (videoMode == V_NTSC) {
      asm.setByteValue("video", 0); // NTSC
      asm.setByteValue("clock", 0); // NTSC
      sids.setPAL(false);
    } else {
      asm.setByteValue("video", 1); // PAL
      asm.setByteValue("clock", 1); // Always PAL...
      sids.setPAL(true);
    }

    // Not release irq?
    if (type != RSID) { // if( !enableTimers ) {
      asm.setByteValue("flags", 0x04);
    }

    songadr = asm.getLabelAddress("playnum");

    System.out.println("SongAddr: " + songadr);
    // If timers? - or if autoinstalling?
    if (paddr == 0)
      asm.setWordValue("irqvec", asm.getLabelAddress("irqret"));
    else
      asm.setWordValue("irqvec", asm.getLabelAddress("irqjob"));

    System.out.println("Jumping to: " + Integer.toString(startAt, 16));
    cpu.jump(startAt);
    cpu.unfreeze();
  }

  public void setPause(boolean pause) {
    if (pause) {
      sids.setPause(true);
      cpu.freeze();
    } else {
      sids.setPause(false);
      cpu.unfreeze();
    }
  }

  public boolean reset() {
    songName = null;
    setPause(false);
    setStatus("Resetting...");
    cpu.reset();
    int again = 20;
    while (!sids.isReady() && again-- > 0) {
      try {
	Thread.currentThread().sleep(500);
	setStatus("Waiting for CPU: " + again);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    setStatus("-");
    return again > 0;
  }


  public int getSong() {
    return currentSong;
  }

  public String getSongInfo() {
    return songName + " by " + songAuthor + ", " + songCopyright;
  }

  private void setMemory(int addr, int data) {
    memory[addr] = data;
  }

  public void init(JSIDListener list, Loader loader, AudioDriver driver) {
    if (DEBUG) {
      try {
	imon = new Debugger();
      } catch (Throwable e) {
      }
    }
    if (imon == null) {
      imon = new DefaultIMon();
    }
    imon.setLevel(2);
    cpu = new JSCPU(imon, "", loader);
    this.loader = loader;
    imon.init(cpu);
    memory = cpu.getMemory();
    cpu.init(sids = new JSIDChipemu());
    sids.init(memory, cpu, list, driver);
  }

  public void start() {
    new Thread(this).start();
  }

  public void run() {
    cpu.start();
  }

  public void stop() {
    cpu.stop();
    sids.audioDriver.shutdown();
  }

  // -------------------------------------------------------------------
  // Querying methods
  // -------------------------------------------------------------------

  public String getSongName() {
    return songName;
  }

  public String getSongAuthor() {
    return songAuthor;
  }

  public String getSongCopyright() {
    return songCopyright;
  }

  public abstract void setSongInfo(String songinfo);

  public abstract void setStatus(String text);
}
