/**
 * This file is a part of JSIDPlay - a Java SID Player
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;


/**
 * Describe class SIDMixerFront here.
 *
 *
 * Created: Fri Nov 04 21:29:29 2005
 *
 * @author <a href="mailto:Joakim@BOTBOX"></a>
 * @version 1.0
 */

import com.dreamfabric.jac64.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.*;
import com.dreamfabric.gui.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.plaf.ButtonUI;

public class SIDMixerFront implements ChangeListener, SIDMixerListener {

  private JPanel panel;

  private DKnob2 delay;
  private DKnob2 feedback;
  private DKnob2 lfoDepth;
  private DKnob2 lfoSpeed;
  private DKnob2 wetDryMix;

  private DKnob2 filterCutoff;
  private DKnob2 filterResonance;
  private DKnob2 filterLFODepth;
  private DKnob2 filterLFOSpeed;
  private DKnob2 volume;

  private DCheckBox delayUnitOn;
  private DCheckBox filterOn;

  private SIDMixer mixer;

  private final static RenderingHints AALIAS =
    new RenderingHints(RenderingHints.KEY_ANTIALIASING,
		       RenderingHints.VALUE_ANTIALIAS_ON);

  public SIDMixerFront(SIDMixer delayUnit) {
    this.panel = new JPanel(new GridLayout(2,1));
    // -------------------------------------------------------------------
    // SIDMixer delay unit
    // -------------------------------------------------------------------
    JPanel panel = new JPanel(new BorderLayout(2,4));
    JPanel jp = new JPanel(new GridLayout(1,5));
    panel.setBackground(new Color(205,205,190));
    jp.setBackground(new Color(205,205,190));

    panel.setBorder(new SoftBevelBorder ( BevelBorder.RAISED ));

    JLabel jl = new JLabel(" SIDMixer Delay Unit") {
	public void paint(Graphics g) {
	  if (g instanceof Graphics2D) {
	    Graphics2D g2d = (Graphics2D) g;
	    g2d.addRenderingHints(AALIAS);
	  }
	  super.paint(g);
	}
      };
    jl.setForeground(new Color(0x80,0x40,0x40));
    jl.setFont(new Font("sans-serif", Font.BOLD | Font.ITALIC, 11));

    JPanel labPanel = new JPanel(new BorderLayout());
    labPanel.setOpaque(false);
    labPanel.add(makeLabel("Delay On:"), BorderLayout.CENTER);
    labPanel.add(delayUnitOn = new DCheckBox(), BorderLayout.EAST);
    delayUnitOn.addChangeListener(this);

    JPanel epanel = new JPanel(new BorderLayout());
    epanel.setOpaque(false);
    epanel.add(jl, BorderLayout.WEST);
    epanel.add(labPanel, BorderLayout.EAST);
    panel.add(epanel, BorderLayout.NORTH);
    panel.add(jp, BorderLayout.CENTER);

    DKnob2 ts;
    ChangeListener cl;
    jp.add(delay = new DKnob2("Delay", "ms"));
    delay.setInterval(1,50,2000);

    jp.add(feedback = new DKnob2("Feedback", "%"));
    jp.add(lfoDepth = new DKnob2("LFO Depth", "%"));
    jp.add(lfoSpeed = new DKnob2("LFO Speed", "Hz"));
    lfoSpeed.setInterval(1,100);
    lfoSpeed.setDivisor(10);
    jp.add(wetDryMix = new DKnob2("Wet/Dry Mix"));
    wetDryMix.setValue((float)0.5);

    delay.addChangeListener(this);
    feedback.addChangeListener(this);
    lfoSpeed.addChangeListener(this);
    lfoDepth.addChangeListener(this);
    wetDryMix.addChangeListener(this);
    if (delayUnit != null) {
      delayUnit.setListener(this);
      mixer = delayUnit;
    }
    this.panel.add(panel);
    // -------------------------------------------------------------------
    // SIDMixer filter and Volume
    // -------------------------------------------------------------------

    panel = new JPanel(new BorderLayout(2,4));
    jp = new JPanel(new GridLayout(1,5));
    panel.setBackground(new Color(205,205,190));
    jp.setBackground(new Color(205,205,190));

    panel.setBorder(new SoftBevelBorder ( BevelBorder.RAISED ));

    jl = makeLabel(" SIDMixer Filter Sweep and Volume");

    labPanel = new JPanel(new BorderLayout());
    labPanel.setOpaque(false);
    labPanel.add(makeLabel("Filter On:"), BorderLayout.CENTER);
    labPanel.add(filterOn = new DCheckBox(), BorderLayout.EAST);
    filterOn.addChangeListener(this);

    epanel = new JPanel(new BorderLayout());
    epanel.setOpaque(false);
    epanel.add(jl, BorderLayout.WEST);
    epanel.add(labPanel, BorderLayout.EAST);
    panel.add(epanel, BorderLayout.NORTH);
    panel.add(jp, BorderLayout.CENTER);

    jp.add(filterCutoff = new DKnob2("Cutoff", "Hz"));
    filterCutoff.setInterval(0, 8000);
    filterCutoff.setIntValue(4000);
    mixer.setMoogCutoff(4000);

    jp.add(filterResonance = new DKnob2("Resonance", ""));
    filterResonance.setInterval(0,100);
    filterResonance.setDivisor(100);

    jp.add(filterLFODepth = new DKnob2("LFO Depth", ""));
    jp.add(filterLFOSpeed = new DKnob2("LFO Speed", "Hz"));
    filterLFOSpeed.setInterval(1,100);
    filterLFOSpeed.setDivisor(10);

    jp.add(volume = new DKnob2("Volume"));
    volume.setValue((float)0.5);


    volume.addChangeListener(this);
    filterResonance.addChangeListener(this);
    filterCutoff.addChangeListener(this);
    filterLFOSpeed.addChangeListener(this);
    filterLFODepth.addChangeListener(this);

    this.panel.add(panel);

    updateValues();
  }

  private JLabel makeLabel(String label) {
    JLabel jl = new JLabel(label) {
	public void paint(Graphics g) {
	  if (g instanceof Graphics2D) {
	    Graphics2D g2d = (Graphics2D) g;
	    g2d.addRenderingHints(AALIAS);
	  }
	  super.paint(g);
	}
      };
    jl.setForeground(new Color(0x80,0x40,0x40));
    jl.setFont(new Font("sans-serif", Font.BOLD | Font.ITALIC, 11));
    return jl;
  }

  public JPanel getPanel() {
    return panel;
  }

  public void stateChanged(ChangeEvent ce) {
    if (mixer == null) return;
    Object src = ce.getSource();
    if (src == delay) {
      mixer.setEchoTime(delay.getIntValue());
    } else if (src == feedback) {
      mixer.setEchoFeedback(feedback.getIntValue());
    } else if (src == lfoSpeed) {
      mixer.setEchoLFOSpeed(lfoSpeed.getIntValue());
    } else if (src == lfoDepth) {
      mixer.setEchoLFODepth(lfoDepth.getIntValue());
    } else if (src == wetDryMix) {
      mixer.setEchoDW(wetDryMix.getIntValue());
    } else if (src == delayUnitOn) {
      mixer.setEffectsOn(delayUnitOn.isSelected());
    } else if (src == volume) {
//      mixer.setMasterVolume(volume.getIntValue());
    } else if (src == filterOn) {
      mixer.setMoogFilterOn(filterOn.isSelected());
    } else if (src == filterResonance) {
      mixer.setMoogResonance(filterResonance.getIntValue());
    } else if (src == filterCutoff) {
      mixer.setMoogCutoff(filterCutoff.getIntValue());
    } else if (src == filterLFOSpeed) {
      mixer.setMoogSpeed(filterLFOSpeed.getIntValue());
    } else if (src == filterLFODepth) {
      mixer.setMoogDepth(filterLFODepth.getIntValue());
    }
  }

  public void updateValues() {
    delay.setIntValue(mixer.getEchoTime());
    feedback.setIntValue(mixer.getEchoFeedback());
    lfoSpeed.setIntValue(mixer.getEchoLFOSpeed());
    lfoDepth.setIntValue(mixer.getEchoLFODepth());
    wetDryMix.setIntValue(mixer.getEchoDW());
    delayUnitOn.setSelected(mixer.isEffectsOn());

//    volume.setIntValue(mixer.getMasterVolume());
    filterCutoff.setIntValue(mixer.getMoogCutoff());
    filterResonance.setIntValue(mixer.getMoogResonance());
    filterLFODepth.setIntValue(mixer.getMoogDepth());
    filterLFOSpeed.setIntValue(mixer.getMoogSpeed());
    filterOn.setSelected(mixer.isMoogFilterOn());
  }

  public static void main(String[] args) {
    SIDMixerFront front = new SIDMixerFront(null);

    JFrame win = new JFrame("Delay Unit Test!");
    win.getContentPane().setLayout(new BorderLayout());
    win.setSize(320,140);
    win.getContentPane().add(front.getPanel(), BorderLayout.CENTER);
    win.setVisible(true);
  }
}
