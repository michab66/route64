/**
 * This file is a part of JaC64 - a Java C64 Emulator
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;

import javax.sound.sampled.*;
import javax.sound.sampled.DataLine.Info;
import com.dreamfabric.jac64.*;

/**
 *
 *
 * @author  Joakim Eriksson (joakime@sics.se)
 * @version $Revision: 1.1 $, $Date: 2005/11/19 08:51:46 $
 */
public class PSID extends SIDVoice {

  public static final int UPDATE_CYCLES = 1000; // 1 x each ms
  public static final int PER_SEC = 1000000 / UPDATE_CYCLES;
  public static final int IO_OFFSET = JSIDChipemu.IO_OFFSET;

  public static final boolean DEBUG = false;

  private int[] memory;

  private final static int GENLEN = SIDVoice6581.GENLEN;

  public static final long SAMPLES_PER_CYCLE_1024 =
    (1024 * SIDVoice6581.SAMPLE_RATE) / 1000000;
  public static final int VOLUME_SIZE = 4096;
  private final static int MICROSEC_PER_GEN = (int)
    ((GENLEN * 1000000L) / SIDVoice6581.SAMPLE_RATE);

  // Modes of play
  public static final int OFF = 0;
  public static final int SAMPLE = 1;
  public static final int NOISE = 2;

  public static final int NO_SOUND = 0;
  public static final int START = 1;
  public static final int CONTINUE = 2;

  // The real output buffer
  byte[] buffer = new byte[65536 * 4];
  int[] quiet = new int[GENLEN];
  int sampleStart;
  int sampleEnd;
  int playSamplePos = 0;
  boolean playSample = false;

  int mode = OFF;
  int lastMode;

  int pvol = 0;
  long lastGenCycles = 0;
  int cycleDiff;

  // For Noice!
  int noiceCount;
  int toneLength;
  int nVol;
  int period;
  int period0;

  // For sample!
  int address;
  int endAddress;
  int delay;
  int addBytes;
  boolean highNybbleFirst;
  int repeat;
  int repeatAddress;

  // Status
  int status = NO_SOUND;
  int samplePos;
  int smpVol;
  int maxSamplePos;
  int currAddr;

  // For knowing if a sample was played or not the last update...
  int lastPlayedSample;

  public PSID(int mem[]) {
    memory = mem;
    System.out.println("PSID Emulator, GENLEN: " + GENLEN);
  }

  public void init() {
  }

  // 0xd01d
  public void soundControl(int data, long cycles) {
    // This controls (starts/stops) a sample!

    switch(data) {
    case 0xfd:
      lastMode = mode;
      mode = OFF;
      if (DEBUG) System.out.println("####### Shutting down sample!!! #####");
      break;
    case 0xfc: // ??? (seems to be wrong order fc/fd ???)
      pvol = 1;
    case 0xfe:
      pvol = 2;;
    case 0xff:
      pvol = 3;
      mode = SAMPLE;
      break;
    default:
      noiceCount = data;
      mode = NOISE;
    }

    // Generate immediately??? (or should we wait until next updateSnd?)
    // Generating full sample immediately requires probably a fast machine
    // to avoid messing up...
    status = START;
    if (!playSample) {
      samplePos = 0;
      playSamplePos = 0;
      // Generate max 16k each time!
      maxSamplePos = 16384;
    } else {
      // Just continue on the sample that is generated already...
      if (maxSamplePos + 16384 < 65535) {
	maxSamplePos = samplePos + 16384;
      }
    }
    genSound(cycles);
  }

  // -------------------------------------------------------------------
  // Startup and continue generate sounds
  // currentSampleStart => set position for where it should start...
  // -------------------------------------------------------------------
  private void genSound(long cycles) {
    if (status == START) {
      if (DEBUG && playSample) {
	System.out.println(">>>>> Sample already playing: "
			   + playSamplePos + " of " + sampleEnd +
			   " start: " + sampleStart + " lastGen: " +
			   lastCycles);
      }

      address = (memory[IO_OFFSET + 0xd41f] << 8) +
	memory[IO_OFFSET + 0xd41e];

      if (lastCycles == 0) {
	lastCycles = cycles;
      }

      // If we not already are playing a sample...
      // If we are - just append it at the end of the last sample...???
      if (!playSample) {
	cycleDiff = (int) (cycles - lastCycles);
	// The sample should start after sampleStart "dead" samples!!!
	int sampleStart = (int) (cycleDiff * SAMPLES_PER_CYCLE_1024) >> 10;
	for (int i = 0, n = sampleStart; i < n; i++) {
	  buffer[i] = 0;
	}
	samplePos = sampleStart;
      }
      smpVol = 15;
    }

    switch (mode) {
    case NOISE:
      if (status == START) {
	toneLength = memory[IO_OFFSET + 0xd43d];
	nVol = memory[IO_OFFSET + 0xd43e];
	period = memory[IO_OFFSET + 0xd43f];
	period0 = memory[IO_OFFSET + 0xd45d];

	if (DEBUG) {
	  System.out.println("*** Noice!: start = " + samplePos + " cycles: " +
			     cycles);
	  System.out.println("ToneLen: " + toneLength);
	  System.out.println("NoiceCount: " + noiceCount);
	  System.out.println("Volume: " + nVol);
	  System.out.println("Period: " + period);
	  System.out.println("Period0: " + period0);
	  System.out.println("Fetch from: " + address);
	}

	// Vol on max before???
	smpVol = 15;
      } else {
	if (DEBUG) System.out.println("### Playing rest of sample");
      }
      while(noiceCount >= 0 && samplePos < maxSamplePos) {
	for (int j = 0, m = toneLength; j <= m; j++) {
	  int data = memory[address + noiceCount];
	  int delay = period0 + period * data;
	  cycleDiff += delay;
	  int nextSamplePos = (int) (cycleDiff * SAMPLES_PER_CYCLE_1024) >> 10;
	  while (samplePos < nextSamplePos)
	    buffer[samplePos++] = (byte) (smpVol << 3);
	  smpVol = (smpVol + nVol) & 15;
	}
	noiceCount--;
      }
      if (DEBUG) System.out.println("End Cycle: " + cycles + cycleDiff);

      sampleEnd = samplePos;
      playSample = true;
      if (noiceCount == -1) {
	status = NO_SOUND;
      } else {
	if (DEBUG) System.out.println("Sample continues!!!");
	status = CONTINUE;
      }

      break;
    case SAMPLE:
      if (status == START) {
	endAddress = (memory[IO_OFFSET + 0xd43e] << 8) +
	  memory[IO_OFFSET + 0xd43d];
	delay = memory[IO_OFFSET + 0xd45d] +
	  (memory[IO_OFFSET + 0xd45e] << 8);
	addBytes = memory[IO_OFFSET + 0xd45f];
	highNybbleFirst = memory[IO_OFFSET + 0xd47d] == 1;
	repeat = memory[IO_OFFSET + 0xd43f];
	repeatAddress = memory[IO_OFFSET + 0xd47e] +
	  (memory[IO_OFFSET + 0xd47f] << 8);

	currAddr = address;
	smpVol = 15;

	if (DEBUG) {
	  System.out.println("*** Sample!");
	  System.out.println("Sample adr: " + address + " - " + endAddress +
			     " loop at " + repeatAddress);
	  System.out.println("Repeats: " + repeat);
	  System.out.println("addBytes: " + addBytes);
	  System.out.println("Nybble order (highfirst): " + highNybbleFirst);
	  System.out.println("Delay: " + delay + " cycles " +
			     ((delay * SAMPLES_PER_CYCLE_1024) >> 10) +
			     " samples ");
	System.out.println("PVol: " + pvol);
	System.out.println("PlayPos: " + playSamplePos);
	System.out.println("CycleDiff: " + cycleDiff);
	}
      } else {
	if (DEBUG) System.out.println("Sample - continues...");
      }

      // High Nibble assumed..
      while (repeat >= 0 && samplePos < maxSamplePos) {
	while (currAddr < endAddress) {
	  int data = memory[currAddr];
	  // Do stuff...

	  smpVol = highNybbleFirst ? (data >> 4) : data & 0x0f;

	  int nextSamplePos = (int) (cycleDiff * SAMPLES_PER_CYCLE_1024) >> 10;
	  int len = buffer.length;
	  while (samplePos < nextSamplePos && samplePos < len) {
	    buffer[samplePos++] = (byte) (smpVol << pvol);

	  }
	  cycleDiff += delay;

	  if (addBytes == 0) {
	    // second Nibble
	    smpVol = highNybbleFirst ? (data & 0x0f) : (data >> 4);
	    nextSamplePos = (int) (cycleDiff * SAMPLES_PER_CYCLE_1024) >> 10;
	    while (samplePos < nextSamplePos && samplePos < len)
	      buffer[samplePos++] = (byte) (smpVol << pvol);
	    cycleDiff += delay;
	  }
	  currAddr += addBytes + 1;
	}
	currAddr = repeatAddress;
	if (repeat != 255) repeat--;
      }

      sampleEnd = samplePos;
      playSample = true;

      if (repeat == -1) {
	status = NO_SOUND;
      } else {
	status = CONTINUE;
      }
      break;
    }
  }

  public void printStatus() {
    System.out.println("Last played mode: " + lastMode);
  }


  int nxtChange;
  int noise = 0;
  long noise_reg = 0x7ffff8;
  byte[] wbuf;

  int irq = 0;
  int pass = 0;

  boolean debugGen = false;


  private long lastCycles = 0;
  private int generated = 0;
  private int[] outBuff = new int[GENLEN];

  public int[] generateSound(long cycles) {
    lastCycles = cycles;

    if (playSample) {
      int len = 0;
      len = sampleEnd - playSamplePos;

      if (len < 0) {
	// Ooops played passed already???
	System.out.println("#### LEN:" + len);
	playSamplePos = 0;
	return quiet;
      }

      if (len < GENLEN) {
	// Write the rest
	for (int i = 0, n = len; i < n; i++) {
	  outBuff[i] = buffer[playSamplePos++];
	}

	if (status == CONTINUE) {
	  if (playSamplePos < 20000) {
	    // Just continue...
	    maxSamplePos = playSamplePos + 16384;
	  } else {
	    // reset and continue...
	    samplePos = 0;
	    maxSamplePos = 16384;
	    playSamplePos = 0;
	  }

	  // Generate more sound, and write a piece more of that (MAXGEN)
	  genSound(cycles);

	  for (int i = len, n = GENLEN; i < n; i++) {
	    outBuff[i] = buffer[playSamplePos++];
	  }
	} else {
	  for (int i = len, n = GENLEN; i < n; i++) {
	    outBuff[i] = 0;
	  }
	}
      } else {
	for (int i = 0, n = GENLEN; i < n; i++) {
	  outBuff[i] = buffer[playSamplePos++];
	}
      }

      if (playSamplePos >= sampleEnd && status != CONTINUE) {
	playSample = false;
	playSamplePos = 0;
	status = NO_SOUND;
      }
      lastPlayedSample = 0;
      return outBuff;
    } else {
      lastPlayedSample++;
      return quiet;
    }
  }
}
