/**
 * This file is a part of JSIDPlay - a Java SID Player
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;
import com.dreamfabric.jac64.*;

/**
 * Describe class JSIDListener here.
 *
 *
 * Created: Tue Aug 02 15:10:25 2005
 *
 * @author <a href="mailto:Joakim@BOTBOX"></a>
 * @version 1.0
 */
public interface JSIDListener {
  public void screenRefresh();
  public void sidUpdate();
}
