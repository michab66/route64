/**
 * This file is a part of JSIDPlay - a Java SID Player
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;
import com.dreamfabric.jac64.*;
import com.dreamfabric.c64utils.*;
/**
 * JSIDChipemu - emulation of neccesary chips for the jsidplayer
 *
 */

/**
 * Implements the VIC chip + some other HW
 *
 * @author  Joakim Eriksson (joakime@sics.se)
 * @version $Revision: 1.2 $, $Date: 2006/04/08 10:06:01 $
 */
public class JSIDChipemu extends ExtChip {
  public static final int IO_OFFSET = JSCPU.IO_OFFSET;
  public static final boolean IRQDEBUG = false;

  public static final int RESID_6581 = 1;
  public static final int RESID_8580 = 2;
  public static final int JACSID = 3;
  
  public static final int IO_UPDATE = 57;
  // This is PAL speed! - will be called each scan line...
  public static final int SCAN_RATE_VICII = 63;
  public static final int SCAN_RATE_VICII_NTSC = 65;

  public static final int SCAN_LINES_PAL = 312;
  public static final int SCAN_LINES_NTSC = 263;

  private long nextScanLine = 0;

  private int scanLines = SCAN_LINES_PAL;
  private int scanRate = SCAN_RATE_VICII;

  ExtChip sidChip;
  
  private int[] memory;
  JSCPU cpu;

  CIA cia[];

  int irqMask = 0;
  int irqFlags = 0;

  private boolean timersOn = true;
  private boolean pause = false;

  private boolean ready = false;
  int reads = 0;

  JSIDListener listener = null;
  AudioDriver audioDriver;
  
  public void setSID(int sid) {
    switch (sid) {
    case RESID_6581:
    case RESID_8580:
      if (!(sidChip instanceof RESIDChip)) {
    if (sidChip != null) sidChip.stop();
        sidChip = new RESIDChip(cpu, audioDriver);
      }
      ((RESIDChip) sidChip).setChipVersion(sid);
      break;
    case JACSID:
      if (!(sidChip instanceof SIDChip)) {
    if (sidChip != null) sidChip.stop();
        sidChip = new SIDChip(cpu, audioDriver);
      }
      break;
    }
  }
  
  public void init(int[] memory, JSCPU cpu, JSIDListener listener,
		   AudioDriver driver) {
    super.init(cpu);
    this.listener = listener;

    cia = new CIA[2];
    cia[0] = new CIA(cpu, IO_OFFSET + 0xdc00, this);
    cia[1] = new CIA(cpu, IO_OFFSET + 0xdd00, this);

    this.memory = memory;
    this.cpu = cpu;

    audioDriver = driver;
    setSID(RESID_6581);
  }

  public void setPAL(boolean pal) {
    if (pal) {
      scanLines = SCAN_LINES_PAL;
      scanRate = SCAN_RATE_VICII;
    } else {
      scanLines = SCAN_LINES_NTSC;
      scanRate = SCAN_RATE_VICII_NTSC;
    }
  }

  public void clearTimers() {
    cia[0].reset();
    cia[1].reset();
  }

  public void setPause(boolean stat) {
    pause = stat;
  }

  public void dumpStatus() {
    cia[0].printStatus();
    cia[1].printStatus();
  }

  // Should be checked up!!!
  private static final int[] IO_ADDRAND = new int[]
    { 0xd03f, 0xd03f, 0xd03f, 0xd03f,
      0xd41f, 0xd41f, 0xd41f, 0xd41f,
      0xd8ff, 0xd9ff, 0xdaff, 0xdbff, // Color ram
      0xdc0f, 0xdd0f, 0xdeff, 0xdfff, // CIA + Expansion...
    };

  public int performRead(int address, long cycles) {
    // dX00 => and address
    // d000 - d3ff => &d063
    int pos = (address >> 8) & 0xf;
    //    System.out.println("Address before: " + address);
    address = address & IO_ADDRAND[pos];
    // System.out.println("Actual address: " + address);

    // Do stuff... - still the old way...
    int val = memory[address + IO_OFFSET];

    switch (address) {
    case 0xd019:
      return irqFlags;
    case 0xd01a:
      return irqMask;
    }

    if (pos == 0xd) {
      return cia[1].performRead(address + IO_OFFSET, cycles);
    } if (pos == 0xc) {
      return cia[0].performRead(address + IO_OFFSET, cycles);
    }
    // Default: return what's in CPU's memory?!
    return val;
  }

  public void performWrite(int address, int data, long cycles) {
    int pos = (address >> 8) & 0xf;
    //    address = address & IO_ADDRAND[pos];

    int old = memory[address];

    // For now: store in CPU's memory - is that correct?
//     System.out.println("Wrote to Chips at " + Integer.toString(address, 16)
// 		       + " = " + Integer.toString(data, 16));

    // Store in the memory given by "CPU"
    memory[address + IO_OFFSET] = data;

    notifyWrite(address + IO_OFFSET, old);
  }


  public void setCurrentMemory(int currMemory[]) {
    memory = currMemory;
  }

  public boolean isReady() {
    return ready;
  }

  public void stop() {
    
  }

  public void reset() {
    ready = false;
    reads = 0;
    irqMask = 0;
    irqFlags = 0;
    // Timers are on by default
    timersOn = true;
    sidChip.reset();
    System.out.println("SIDS reset...");
  }

  // This is the vicMemory where data written exists...
  public int[] vicMemory = new int[0x1000];
  int frq;
  public void notifyWrite(int address, int oldData) {
    long cycles = cpu.getCycles();

    int data = memory[address];
    if (address >= (0xd400 + IO_OFFSET) &&
        address < (0xd500 + IO_OFFSET)) {
//      System.out.println("Writing to SID Chip at: " + Hex.hex2(address & 0xfff1f) + " = " + data);
      sidChip.performWrite(address & 0xfff1f, data, cycles);
    }
    switch(address) {
  // -------------------------------------------------------------------
  // Other chips...
  // -------------------------------------------------------------------

    case IO_OFFSET + 0xd011 :
      vicMemory[0x11] = data;
      // Restore!
      memory[IO_OFFSET + 0xd011] =
	(memory[IO_OFFSET + 0xd011] & 0x7f) | ((vbeam & 0x100) >> 1);
      break;

      // d012 -> raster position
    case IO_OFFSET + 0xd012 :
//       System.out.println("Setting Raster: " + data);
      vicMemory[0x12] = data;
      // Restore!
      memory[address] = vbeam & 255;
      break;
    case IO_OFFSET + 0xd019 : {
      if ((data & 0x80) != 0) data = 0xff;
      int latchval = 0xff ^ data;
      if (IRQDEBUG)
      System.out.println("Latching VIC-II: " + Integer.toString(data, 16)
			 + " on " + Integer.toString(memory[address], 16) +
			 " 0x19 = " + Integer.toString(vicMemory[0x19], 16) +
			 " latch: " + Integer.toString(latchval, 16));
      irqFlags &= latchval;
      vicMemory[0x19] &= latchval;
      memory[address] = vicMemory[0x19];

      // Is this "flagged" off?
      if ((vicMemory[0x19] & 0x0f & vicMemory[0x1a]) == 0) {
	clearIRQ(VIC_IRQ);
      }
    }
      break;

    case IO_OFFSET + 0xd01a:
      irqMask = data;

      // Check if IRQ should trigger or clear!
      if ((irqMask & 0x0f & irqFlags) != 0) {
	irqFlags |= 0x80;
	setIRQ(VIC_IRQ);
      } else {
	clearIRQ(VIC_IRQ);
      }
      break;

    case IO_OFFSET + 0xdc00:
    case IO_OFFSET + 0xdc01:
      // Count keyboard updates!!!
      if (!ready && (reads++ > 20)) {
	System.out.println("CPU Ready!!");
	ready = true;
	reads = 0;
      }
    case IO_OFFSET + 0xdc02:
    case IO_OFFSET + 0xdc03:
    case IO_OFFSET + 0xdc04:
    case IO_OFFSET + 0xdc05:
    case IO_OFFSET + 0xdc06:
    case IO_OFFSET + 0xdc07:
    case IO_OFFSET + 0xdc08:
    case IO_OFFSET + 0xdc09:
    case IO_OFFSET + 0xdc0a:
    case IO_OFFSET + 0xdc0b:
    case IO_OFFSET + 0xdc0c:
    case IO_OFFSET + 0xdc0d:
    case IO_OFFSET + 0xdc0e:
    case IO_OFFSET + 0xdc0f:
      cia[0].performWrite(address, data, cycles);
      break;
    case IO_OFFSET + 0xdd00:
    case IO_OFFSET + 0xdd01:
    case IO_OFFSET + 0xdd02:
    case IO_OFFSET + 0xdd03:
    case IO_OFFSET + 0xdd04:
    case IO_OFFSET + 0xdd05:
    case IO_OFFSET + 0xdd06:
    case IO_OFFSET + 0xdd07:
    case IO_OFFSET + 0xdd08:
    case IO_OFFSET + 0xdd09:
    case IO_OFFSET + 0xdd0a:
    case IO_OFFSET + 0xdd0b:
    case IO_OFFSET + 0xdd0c:
    case IO_OFFSET + 0xdd0d:
    case IO_OFFSET + 0xdd0e:
    case IO_OFFSET + 0xdd0f:
      cia[1].performWrite(address, data, cycles);
      break;
    }
  }

  public void clock(long cycles) {
    if(nextScanLine <= cycles) {
      // vicTic automatically tries to make 50 (or any other target rate)
      // scans per second
      // Always run vicTic even when not IO is on...
      vicTic(cycles);
      nextScanLine += scanRate;
    }
  }


  public void enableTimers(boolean on) {
    System.out.println("ENABLE_TIMERS: " + on);
    timersOn = on;
  }



  int vbeam = 0;
  boolean updating = false;
  long nextSID = 0;
  int rnd;
  long oldcyc;
  float sleep = 2;
  float percent = 0;
  int mes = 0;

  int trigger = 0;
  int frame = 0;

  public int vicTic(long cycles) {
    int irqLatch = vicMemory[0x19];

    boolean irq = false;

	if (vbeam == 311) { // This is 50 each second...
	  if (!timersOn)
	    memory[IO_OFFSET + 0xd019] |= 0x1;
	  if (listener != null) {
	    listener.screenRefresh();
	  }
      irq = true;
	}
	if (timersOn) {
	  irq = false;
    }
    
	irq = vbeam == 310;
	if (irq) {
	  memory[IO_OFFSET + 0xd019] |= 0x81;
	} else {
	  memory[IO_OFFSET + 0xd019] = 0;
	}

    // This should be SID-based...
    memory[IO_OFFSET + 0xd41b] = (rnd++) & 0xff;

    memory[IO_OFFSET + 0xd012] = vbeam & 0xff;
    memory[IO_OFFSET + 0xd011] = (memory[IO_OFFSET + 0xd011] & 0x7f) |
      ((vbeam & 0x100) >> 1);

    // Compare d011 + d012 to the raster position in vicMem
    int irqComp = ((vicMemory[0x11] & 0x80) << 1) + vicMemory[0x12];

    // Not nice... FIX THIS!!!
    if (irqComp > 312) irqComp &= 0xff;

    if ((irqFlags & 1) == 0 && (irqComp == vbeam)) {
      irqFlags |= 0x1;

      if ((irqMask & 1) != 0) {
        irqFlags |= 0x80;
//      System.out.println("Trigger IRQ at: " + vbeam + " trigger: " +
//      trigger++ + " frame " + frame);
        setIRQ(VIC_IRQ);
      }
    }

    vbeam = (vbeam + 1) % scanLines;
    if (vbeam == 0) frame++;
    return 0;
  }
}
