/**
 * This file is a part of JaC64 - a Java C64 Emulator
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 * This is the CPU file for Commodore 64 with its
 * ROM files and memory management, etc.
 *
 * @(#)cpu.java	Created date: 99-5-17
 *
 */
package com.dreamfabric.jsidplay;
import com.dreamfabric.jac64.*;
import com.dreamfabric.c64utils.*;
import java.io.*;

/**
 * CPU "implements" the C64s 6510 processor in java code.
 * reimplemented from old CPU.java
 *
 * @author  Joakim Eriksson (joakime@sics.se)
 * @version $Revision:$, $Date:$
 */
public class JSCPU extends MOS6510Core // CPUCore // MOS6510Core
{
  // The IO RAM memory at 0x10000 (just since there is RAM there...)
  public static final int IO_OFFSET = 0x10000 - 0xd000;

  public static final int BASIC_ROM2 = 0x1a000;
  public static final int KERNAL_ROM2 = 0x1e000;
  public static final int CHAR_ROM2 = 0x1d000;

  // Defaults for the ROMs
  public boolean basicROM = true;
  public boolean kernalROM = true;
  public boolean charROM = false;
  public boolean ioON = true;

  private int romFlag = 0xa000;

  // The state of the program (runs if running = true)
  public boolean running = true;

  // True if loop should exit after a reset???
  public boolean exit = false;

  private static final long CYCLES_PER_DEBUG = 100000000;
  public static final boolean DEBUG = false;

  private static final long IO_UPDATE = JSIDChipemu.SCAN_RATE_VICII;
  private long nextIOUpdate = 0;
  private Loader loader;
  private boolean freeze = false;

  public JSCPU(IMonitor m, String cb, Loader loader) {
    super(m, cb);
    this.loader = loader;
    memory = new int[0x20000];
  }

  private final void schedule(long cycles) {
    chips.clock(cycles);
    if (cycles >= scheduler.nextTime) {
      TimeEvent t = scheduler.popFirst();
      if (t != null) {
        // Give it the actual time also!!!
        t.execute(cycles);
      };
    }
  }

  // Reads the memory with all respect to all flags...
  protected final int fetchByte(int adr) {
    cycles++;
    schedule(cycles);
    if ((romFlag & adr) == romFlag) {
      return memory[rindex = adr | 0x10000];
    } else if ((adr & 0xf000) == 0xd000) {
      if (ioON) {
        return chips.performRead(rindex = adr, cycles);
      } else if (charROM) {
        return memory[rindex =adr | 0x10000];
      } else {
        return memory[rindex = adr];
      }
    } else {
      return memory[rindex = adr];
    }
  }

  public String getName() {
    return "jsidplay CPU";
  }
  
  private void fixRindex(int adr) {
    // ROM/RAM address fix
    if ((basicROM && ((adr & 0xe000) == 0xa000)) ||
	(kernalROM && ((adr & 0xe000) == 0xe000)) ||
	(charROM && ((adr & 0xf000) == 0xd000))) {
      // Add ROM address for the read!
      adr |= 0x10000;
    }
    rindex = adr;
  }

  // A byte is written directly to memory or to ioChips
  protected final void writeByte(int adr, int data) {
    cycles++;
    schedule(cycles);
    if (adr <= 1) {
      memory[adr] = data;
      int p = (memory[0] ^ 0xff) | memory[1];

      kernalROM = ((p & 2) == 2); // Kernal on
      basicROM = ((p & 3) == 3); // Basic on

      charROM = ((p & 3) != 0) && ((p & 4) == 0);
      // ioON is probably not correct!!! Check against table...
      ioON = ((p & 3) != 0) && ((p & 4) != 0);

      if (basicROM)
        romFlag = 0xa000;
      else if (kernalROM)
        romFlag = 0xe000;
      else
        romFlag = 0x10000; // No Rom at all (Basic / Kernal)
    }

    adr &= 0xffff;
    if (ioON && ((adr & 0xf000) == 0xd000)) {
      chips.performWrite(adr, data, cycles);
    } else {
      memory[adr] = data;
    }
  }

  public void patchROM(PatchListener list) {
    this.list = list;

    int pos = 0xf49e | 0x10000;
    memory[pos++] = M6510Ops.JSR;
    memory[pos++] = 0xd2;
    memory[pos++] = 0xf5;

    System.out.println("Patched LOAD at: " + Hex.hex2(pos));
    memory[pos++] = LOAD_FILE;
    memory[pos++] = M6510Ops.RTS;
  }

  public void runBasic() {
    memory[631] = (int) 'R';
    memory[632] = (int) 'U';
    memory[633] = (int) 'N';
    memory[634] = 13;//enter
    memory[198] = 4; //length
  }

  protected void installROMS() {
    loadROM(loader.getResourceStream("/roms/kernal.c64"), KERNAL_ROM2, 0x2000);
    loadROM(loader.getResourceStream("/roms/basic.c64"), BASIC_ROM2, 0x2000);
    loadROM(loader.getResourceStream("/roms/chargen.c64"), CHAR_ROM2, 0x1000);
  }


  public void run(int address) {
    reset();
    exit = false;
    running = true;
    loop(address);
  }


  // Takes the thread and loops!!!
  public void start() {
    while(!exit) {
      run(0xfce2); // Power UP reset routine!
      if (!exit) {
	monitor.info("Resetting!!!!");
	reset();
      }
    }
    System.out.println("CPU Thread exited...");
  }

  public void stop() {
    // stop completely
    running = false;
    exit = true;
    chips.stop();
  }

  public void reset() {
    running = false;
    exit = false;
    writeByte(1, 7);
    unfreeze();
    chips.reset();
    super.reset();
  }


  public void freeze() {
    freeze = true;
  }

  public void unfreeze() {
    freeze = false;
  }

  /**
   * The main emulation <code>loop</code>.
   *
   * @param startAdress an <code>int</code> value that represent the
   * starting address of the emulator
   */
  public void loop(int startAdress) {
    // The processor flags
    pc = startAdress;
    int wasdebug = 0;
    long next_print = cycles + CYCLES_PER_DEBUG;
    // How much should this be???

    monitor.info("Starting CPU at: " + Integer.toHexString(pc) );

    try {
	while (running) {

	  // Debugging?
	  if (monitor.isEnabled()){// || interruptInExec > 0 || wasdebug > 0) {
	    fixRindex(pc); // sets the rindex!
// 	    if (wasdebug > 0) {
// 	      monitor.setEnabled(true);
// 	    } else {
// 	      monitor.setEnabled(false);
// 	    }
	    monitor.disAssemble(memory,rindex,acc,x,y,
				(byte)getStatusByte(),interruptInExec,
				lastInterrupt);
// 	    if (interruptInExec > 0) {
// 	      wasdebug = 100;
// 	    }
	  }

	  // Run one instruction!
	  emulateOp();

	  while (freeze) {
	    Thread.currentThread().sleep(100);
	  }

	  if (nextIOUpdate < cycles) {
	    chips.clock(cycles);
	    nextIOUpdate += IO_UPDATE;

	    if(next_print < cycles) {
	      long sec = System.currentTimeMillis() - lastMillis;
	      int level = monitor.getLevel();

	      if (level > 1) {
		monitor.info("--------------------------");
		monitor.info("Nr ins:" + nr_ins + " sec:" +
			     (sec) + " -> " + ((nr_ins * 1000) / sec) +
			     " ins/s"  + "  " +
			     " clk: " + cycles +
			     " clk/s: "+((CYCLES_PER_DEBUG * 1000)/ sec) +
			     "\n" + ((nr_irq * 1000) / sec));
		if (level > 2) monitor.disAssemble(memory,rindex,acc,x,y,(byte)getStatusByte(),interruptInExec, lastInterrupt);
		monitor.info("--------------------------");
	      }
	      nr_irq = 0;
	      nr_ins = 0;
	      lastMillis = System.currentTimeMillis();
	      next_print = cycles + CYCLES_PER_DEBUG;
	    }
	  }
	  nr_ins++;
	}
    } catch (Exception e) {
      monitor.error("Exception in loop " + pc + " : " + e);
      e.printStackTrace();
      monitor.disAssemble(memory,rindex,acc,x,y,(byte) getStatusByte(),interruptInExec, lastInterrupt);
    }
  }

}
