/**
 * This file is a part of JSIDPlay - a Java SID Player
 * Main Developer: Joakim Eriksson (Dreamfabric.com)
 * Contact: joakime@sics.se
 * Web: http://www.dreamfabric.com/c64
 * ---------------------------------------------------
 */

package com.dreamfabric.jsidplay;

import com.dreamfabric.jac64.*;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Canvas;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JComponent;

/**
 * Describe class SIDCanvas here.
 *
 *
 * Created: Tue Aug 02 14:53:07 2005
 *
 * @author <a href="mailto:Joakim@BOTBOX"></a>
 * @version 1.0
 */
public class SIDMixerDisplay extends JComponent {

  private static final int SAMPLE_SIZE = 512;
  private static final int STEP_SIZE = 4;
  private int[] sampleBuffer = new int[SAMPLE_SIZE];
  private int samplePos = 0;

  private boolean fftDone = false;

  private float[] fSamples = new float[SAMPLE_SIZE];
  private float[] fft;

  private static int[]
    COLOR_SET = com.dreamfabric.jac64.VICConstants.COLOR_SETS[2];

  private static final Color PENCOLOR = new Color(COLOR_SET[14]);
  private static final Color BORDERCOLOR = new Color(COLOR_SET[6]);

  public SIDMixerDisplay() {
    super();
    setBackground(BORDERCOLOR);
    setForeground(PENCOLOR);
    setDoubleBuffered(true);
    setOpaque(true);
  }

  public Dimension getPreferredSize() {
    return new Dimension(8 * 30, 32);
  }

  public void updateSamples(int[] samples, int count) {
    // Store the samples...
    for (int i = 0, n = count; i < n; i += 2) {
      sampleBuffer[samplePos = (samplePos + 1) % SAMPLE_SIZE] = samples[i];
    }
    fftDone = false;
  }

  private void doFFT() {
    if (!fftDone) {
      for (int i = 0, n = SAMPLE_SIZE; i < n; i++) {
	fSamples[i] = (float) sampleBuffer[i];
      }
      fft = FastFourierTransform.fftMag(fSamples);
      fftDone = true;
    }
  }

  public void paintComponent(Graphics g) {
    doFFT();
    //long time = System.nanoTime();
    int height = getHeight();
    int width = getWidth() - 4;
    float w = (width * 0.49f) / (SAMPLE_SIZE / STEP_SIZE);
    g.setColor(getBackground());
    g.fillRect(0, 0, getWidth(), height);

    g.setColor(getForeground());
    int last = height * sampleBuffer[(samplePos) % SAMPLE_SIZE] / 16000;
    for (int i = 0, n = SAMPLE_SIZE - 1; i < n; i += STEP_SIZE) {
      int x = 2 + (int) (w * (i / STEP_SIZE));
      g.drawLine(x, height / 2 - last,
		 x + 1, height / 2 - (last = height *
				      sampleBuffer[(samplePos + i + 1) % SAMPLE_SIZE] / 16000));
    }
    fft[0] = 0.0f;
    for (int i = 0, n = (fft.length * 2) / STEP_SIZE; i < n; i++) {
      int fftI = (int) (fft[i] / 20.0);
      int x = 4 + width / 2 + (int) (w * i);
      g.fillRect(x, height - fftI, 1, fftI);
    }
  }
}
