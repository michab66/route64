package com.dreamfabric.jsidplay;

import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;
import java.awt.Image;
import java.awt.Color;
import com.dreamfabric.jac64.VICConstants;

/**
 * Describe class C64TextRenderer here.
 *
 *
 * Created: Sun Jan 07 22:13:03 2007
 *
 * @author <a href="mailto:Joakim@BOTBOX"></a>
 * @version 1.0
 */
public class C64TextRenderer {

  private int[] memory;
  private int[] mem;
  private MemoryImageSource mis;
  private Image screen;

  private int width;
  private int height;

  private int[] COLOR_SET = VICConstants.COLOR_SETS[2];
  private int[] color = new int[] { COLOR_SET[6], COLOR_SET[14]};

  /**
   * Creates a new <code>C64TextRenderer</code> instance.
   *
   */
  public C64TextRenderer(int[] memory, int width, int height) {
    this.memory = memory;
    // Widht is i no chars!
    width = width * 8;
    mem = new int[width * height];
    mis = new MemoryImageSource(width, height, mem, 0, width);
    mis.setAnimated(true);
    mis.setFullBufferUpdates(true);
    screen = Toolkit.getDefaultToolkit().createImage(mis);


    this.width = width;
    this.height = height;
  }

  public void setColor(int cnum, int colorVal) {
    color[cnum] = colorVal;
  }

  public void setCBMColor(int cnum, int cval) {
    color[cnum] = COLOR_SET[cval & 15];
  }

  public Image getImage() {
    return screen;
  }

  public void renderText(String text) {
    for (int i = 0, n = text.length(); i < n; i++) {
      char c = text.charAt(i);
      if (Character.isLetter(c)) {
	c = (char) (c - 'a' + 1);
      }
      c = (char) (c & 0xff);
      int pos = JSCPU.CHAR_ROM2 + c * 8;
      int x = i * 8;
      for (int j = 0, m = 8; j < m; j++) {
	int d = memory[pos + j];
	int mpos = x + j * width;
	renderByte(mpos, d);
      }
    }
    mis.newPixels();
  }

  private void renderByte(int mpos, int data) {
    for (int i = 7, n = 0; i >= n; i--) {
      mem[mpos++] = color[(data >> i) & 1];
    }
  }

}
